- 👋 Hi, I’m @confronter
- 👀 I’m interested in whatsapp bot
- 🌱 I’m currently learning node.js
- 💞️ I’m looking to collaborate on no one
- 📫 How to reach me email
- 😄 Pronouns: any
- ⚡ Fun fact: am not funny

<!---
confronter/confronter is a ✨ special ✨ repository because its `README.md` (this file) appears on your GitHub profile.
You can click the Preview link to take a look at your changes.
--->
